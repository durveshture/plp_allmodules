import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowImageComponent } from './show-image/show-image.component';

const routes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: 'images', component: ShowImageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
