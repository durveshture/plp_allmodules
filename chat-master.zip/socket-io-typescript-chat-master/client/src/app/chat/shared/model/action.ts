export enum Action {
    JOINED,
    LEFT,
    RENAME
}
