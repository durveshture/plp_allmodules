export enum Event {
    CONNECT = 'connect',
    DISCONNECT = 'disconnect'
}
