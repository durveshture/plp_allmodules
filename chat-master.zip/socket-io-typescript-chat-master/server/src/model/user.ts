export class User {
    constructor(private name: string) {}
}