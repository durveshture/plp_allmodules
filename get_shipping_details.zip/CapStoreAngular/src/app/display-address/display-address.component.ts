import { Component, OnInit } from '@angular/core';
import { AddressModel } from '../model/address-model';
import { Router } from '@angular/router';
import { AddressService } from '../address.service';

@Component({
  selector: 'app-display-address',
  templateUrl: './display-address.component.html',
  styleUrls: ['./display-address.component.css']
})
export class DisplayAddressComponent implements OnInit {
  allAddress: AddressModel[];

  public show: boolean = false;
  public radio: any = 'Show';


  confirmationStatus;
  constructor(private router: Router, private Service: AddressService) {
    this.allAddress = [];
    this.allAddress = this.Service.display();
  }

  ngOnInit() {
  }
  addAddress() {
    // navigate to home page on click of Go to Home button
    this.router.navigate(['/address']);
  }

  editAddress(index: number, editedAddress: AddressModel) {
    this.Service.editAddress(index);

  }


  toggle(index:number) {
  //   this.allAddress[index];
    this.show = !this.show;


    if (this.show)
      this.radio = "Hide";
    else
      this.radio= "Show";
  }

  deleteAddress(index: number) {
    
    this.confirmationStatus = confirm('Do you want to delete the address?');
    if (this.confirmationStatus) {
      this.Service.delete(index);
    }
  }
}
