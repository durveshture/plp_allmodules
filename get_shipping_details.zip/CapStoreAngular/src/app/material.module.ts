import { NgModule } from '@angular/core';
import {  MatButtonModule, MatMenuModule } from '@angular/material';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatRadioModule} from '@angular/material/radio';
//import {FormBuilder, FormGroup} from '@angular/forms';


@NgModule({
  imports: [
    MatButtonModule,
    MatMenuModule,MatCardModule,MatFormFieldModule,
    MatInputModule,MatRadioModule
  ],
  exports:[
    MatButtonModule,
    MatMenuModule,MatCardModule,MatFormFieldModule,
    MatInputModule,MatRadioModule
  ]
})
export class MaterialModule { }
