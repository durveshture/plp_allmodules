export class AddressModel {
    pincode:number;
    address1: String;
    address2: String;
    city: String;
    state: String;
    landmark:String;

    
}