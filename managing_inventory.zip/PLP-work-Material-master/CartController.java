package com.capstore.controller;

import java.util.ArrayList;
import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Cart;
import com.capstore.bean.CartProduct;
import com.capstore.bean.Customer;
import com.capstore.bean.Product;
import com.capstore.service.CartService;
import com.capstore.service.CustomerService;
import com.capstore.service.IProductService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/cart")
public class CartController {

	@Autowired
	private IProductService pservice;
	@Autowired
	private CustomerService cservice;

	@Autowired
	private CartService cartService;

	/**
	 * @author Ajay Amrutkar
	 * @param custId
	 * @param productId
	 * @param cart
	 */
	@PostMapping(path = "/add/{custId}/{productId}/{quantity}", consumes = "application/json", produces = "application/json")
	public ResponseEntity<String> addToCart(@PathVariable("custId") int custId,
			@PathVariable("productId") int productId, @PathVariable("quantity") int quantity, @RequestBody Cart cart) {
		Customer cust = cservice.getCustomer(custId);
		Product prod = pservice.getProduct(productId);
		cart.setCustomerFromCart(cust);
		CartProduct cartProd = new CartProduct();
		cartProd.setCart(cart);
		cartProd.setProduct(prod);
		cartProd.setQuantity(quantity);
		cart.addCartProduct(cartProd);
		cartService.saveCart(cart);
		return new ResponseEntity<String>("product added to cart", HttpStatus.OK);
	}

	/**
	 * @author Ajay Amrutkar
	 * @param custId
	 * @return List<CartProduct>
	 */
	@GetMapping(path = "/{custId}")
	public ResponseEntity<Cart> cartProducts(@PathVariable int custId) {
		Customer cust = cservice.getCustomer(custId);
		Cart cart = cust.getCart();
		// List<CartProduct> cartProd = cart.getCartProducts();
		return new ResponseEntity<Cart>(cart, HttpStatus.OK);
	}

	@DeleteMapping(path = "/{cartId}")
	public void deleteCart(@PathVariable int cartId) {
		cartService.delete(cartId);
	}

	@DeleteMapping("/product/{cartProdId}")
	public void deleteCartProduct(@PathVariable("cartProdId") int cartProdId) {
		cartService.delteCartProduct(cartProdId);
	}
}
