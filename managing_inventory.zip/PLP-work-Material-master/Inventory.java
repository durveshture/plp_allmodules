/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.4
 */
package com.capstore.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "inventory")
@SequenceGenerator(name = "invseq", sequenceName = "inventory_seq", initialValue = 101)
public class Inventory {
	@Id
	@Column(name = "inventory_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "invseq")
	private int id;

	@Column(name = "product_description", length = 250)
	private String description;

	@Column(name = "product_price")
	private double price;

	@Column(name = "product_quantity")
	private long quantity;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@JsonIgnore
	public Product getProduct() {
		return productFromInventory;
	}

	public void setProduct(Product product) {
		this.productFromInventory = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	/************** Relationships ******************/
	@JsonBackReference(value = "product-inventory")
	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product productFromInventory;

	@JsonBackReference(value = "merchant-inventory")
	@ManyToOne
	@JoinColumn(name = "merchant_id")
	private Merchant merchant;
}
