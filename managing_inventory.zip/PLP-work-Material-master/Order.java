/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.3
 */
package com.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "cap_order")
@SequenceGenerator(name = "orderseq", sequenceName = "order_seq", initialValue = 101)
public class Order {

	@Id
	@Column(name = "order_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "orderseq")
	private int id;

	@Column(name = "order_date", length = 10)
	private String date;

	@Column(name = "order_amount")
	private double amount;

	/************** Relationships ******************/
	@JsonBackReference(value = "customer-order")
	@ManyToOne
	@JoinColumn(name = "customer_id")
	private Customer customerFromOrder;

	@OneToOne
	@JoinColumn(name = "address_id")
	private Address addressFromOrder;

	@OneToOne
	@JoinColumn(name = "coupon_id")
	private Coupon couponFromOrder;

	@JsonManagedReference(value = "order-product")
	@OneToMany(mappedBy = "order", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<OrderProduct> orderProducts;

	public List<OrderProduct> getOrderProducts() {
		return orderProducts;
	}

	public void setOrderProducts(List<OrderProduct> orderProducts) {
		this.orderProducts = orderProducts;
	}

	public void addOrderProduct(OrderProduct orderProduct) {
		this.getOrderProducts().add(orderProduct);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@JsonIgnore
	public Customer getCustomerFromOrder() {
		return customerFromOrder;
	}

	public void setCustomerFromOrder(Customer customer) {
		this.customerFromOrder = customer;
	}

	public Address getAddressFromOrder() {
		return addressFromOrder;
	}

	public void setAddressFromOrder(Address addressFromOrder) {
		this.addressFromOrder = addressFromOrder;
	}

	public Coupon getCouponFromOrder() {
		return couponFromOrder;
	}

	public void setCouponFromOrder(Coupon couponFromOrder) {
		this.couponFromOrder = couponFromOrder;
	}

}
