package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "product_wishlist")
@SequenceGenerator(name = "prodwishseq", sequenceName = "prodwish_seq", initialValue = 101)
public class ProductWishList {

	@Id
	@Column(name = "pw_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "prodwishseq")
	private int id;

	@JsonBackReference(value = "customer-wishlist")
	@ManyToOne
	@JoinColumn(name = "wishlist_id")
	private WishList wishList;

	@JsonBackReference(value = "product-wishlist")
	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product productFromWishList;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public WishList getWishList() {
		return wishList;
	}

	public void setWishList(WishList wishList) {
		this.wishList = wishList;
	}

	public Product getProductFromWishList() {
		return productFromWishList;
	}

	public void setProductFromWishList(Product productFromWishList) {
		this.productFromWishList = productFromWishList;
	}

}
