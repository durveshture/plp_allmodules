import { Component, ViewChild } from '@angular/core';
import { ServiceService } from './service.service';
import { ModelCap } from './models/modelCap';
import { MatSort, MatSortable, MatTableDataSource, MatButtonModule, MatSliderModule} from '@angular/material';
import { MostView } from './models/mostView';
import { Inventory } from './models/inventory';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  @ViewChild(MatSort) sort: MatSort;
  title = 'CapStore';
  dataSource;
  myModel: 1;
  searchKey: string;
  displayedColumns =['id', 'name','brand', 'price', 'actions'];
  displayedColumns1 =['id', 'name','brand', 'price',];
  product: any[];
  capArrOfObj: ModelCap[] = [];
  capArrOfObj1:ModelCap[]=[];
  resultTrue = false;
  service: any;
  product1:ModelCap;
    product2:ModelCap;
    product3:ModelCap;
    mostView1:MostView;
    mostView2:MostView;
    mostView3:MostView;
    inventory1:Inventory;
    inventory2:Inventory;
    inventory3:Inventory;
    price:number;

  constructor(private serviceService: ServiceService) {
    
  }

  ngOnInit() {
     this.getAll();
    
    this.product1= new ModelCap();
    this.product2= new ModelCap();
    this.product3= new ModelCap();
    this.mostView1= new MostView();
    this.mostView2= new MostView();
    this.mostView3= new MostView();
    this.inventory1=new Inventory();
    this.inventory2=new Inventory();
    this.inventory3=new Inventory();

    this.inventory1.price=700;
    this.inventory1.id=1;
    this.inventory2.price=1700;
    this.inventory2.id=2;
    this.inventory3.price=8000;
    this.inventory3.id=3;


    this.mostView1.viewCount=6;
    this.mostView1.soldCount=205;
    this.mostView2.viewCount=55;
    this.mostView2.soldCount=46;
    this.mostView3.viewCount=300;
    this.mostView3.soldCount=2;

    this.product1.name="galaxy s10";
    this.product1.brand="samsung";
    this.product1.id=1;
    this.product2.name="iphone8";
    this.product2.brand="apple";
    this.product2.id=2;
    this.product3.name="z2plus";
    this.product3.brand="lenovo";
    this.product3.id=3;
    this.product1.mostView=this.mostView1;
    this.product2.mostView=this.mostView2;
    this.product3.mostView=this.mostView3;
    this.product1.inventory=this.inventory1;
    this.product2.inventory=this.inventory2;
    this.product3.inventory=this.inventory3;

    this.capArrOfObj1.push(this.product3);
    this.capArrOfObj1.push(this.product1);
    this.capArrOfObj1.push(this.product2);
    this.capArrOfObj=this.capArrOfObj1;
  }
  getAll() {
    console.log(this.capArrOfObj);
    this.serviceService.getProducts().subscribe(
      result => {
        this.capArrOfObj = result;
        this.resultTrue = true;
        this.dataSource = new MatTableDataSource(this.capArrOfObj);
        this.dataSource.sort = this.sort;
       }

    )
    this.dataSource = new MatTableDataSource(this.capArrOfObj);
   
  }
  sortByMostViewed() {
   
    this.capArrOfObj1.sort((a, b) => a.mostView.viewCount > b.mostView.viewCount ? 1 : ((a.mostView.viewCount < b.mostView.viewCount) ? -1 : 0));
    
    this.dataSource = new MatTableDataSource(this.capArrOfObj1);
   
   
  }

  sortBySoldCount() {
    console.log(this.capArrOfObj1);
    this.capArrOfObj1.sort((a, b) => a.mostView.soldCount > b.mostView.soldCount ? 1 : ((a.mostView.soldCount < b.mostView.soldCount) ? -1 : 0));
    
    this.dataSource = new MatTableDataSource(this.capArrOfObj1);
   
   console.log(this.capArrOfObj1);
  }

  sortByRangeOfPrice() {
   
    // console.log(this.price);
    this.dataSource = new MatTableDataSource(this.capArrOfObj);
    this.capArrOfObj1=this.capArrOfObj;
    if(this.price<1000) {
      this.capArrOfObj1=this.capArrOfObj1.filter((a)=>a.inventory.price<1000);
      this.dataSource = new MatTableDataSource(this.capArrOfObj1);
    }else if(this.price>1000 && this.price<3000){
      this.capArrOfObj1=this.capArrOfObj1.filter((a)=>a.inventory.price>1000 && a.inventory.price<3000);
      this.dataSource = new MatTableDataSource(this.capArrOfObj1);
    }else if(this.price>3000 && this.price<7000){
      this.capArrOfObj1=this.capArrOfObj1.filter((a)=>a.inventory.price>3000 && a.inventory.price<7000);
      this.dataSource = new MatTableDataSource(this.capArrOfObj1);
    }else if(this.price>7000 && this.price<10000){
      this.capArrOfObj1=this.capArrOfObj1.filter((a)=>a.inventory.price>7000 && a.inventory.price<10000);
      this.dataSource = new MatTableDataSource(this.capArrOfObj1);
    }else{
      this.dataSource = new MatTableDataSource(this.capArrOfObj);
    this.capArrOfObj1=this.capArrOfObj;
    }

  }
    
  
}
