export class Inventory{
    id: number;
    description: string;
    price: number;
    quantity: number;
    
}