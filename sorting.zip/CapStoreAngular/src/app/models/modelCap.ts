import { MostView } from './mostView';
import { Inventory } from './inventory';

export class ModelCap{
    id: number;
    catId: number;
    name: String;
    brand: String;
     mostView:MostView;
     inventory:Inventory;
}