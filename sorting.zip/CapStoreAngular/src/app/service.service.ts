import { Injectable } from '@angular/core';
import { ModelCap } from './models/modelCap';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  private baseUrl = 'http://localhost:8880';
  capArrOfObj: ModelCap[];
  constructor( private http: HttpClient) { 
    this.capArrOfObj = [];
  }
  getProducts() {

    return this.http.get<ModelCap[]>(this.baseUrl+'/all');
  
  }

  
// sort() {
//   this.capArrOfObj.sort((a, b) => a.productPrice > b.productPrice ? 1 : ((a.productPrice < b.productPrice) ? -1 : 0));
//   return this.capArrOfObj;
// }
}